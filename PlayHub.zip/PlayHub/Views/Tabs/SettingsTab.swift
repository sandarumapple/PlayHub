//
//  SettingsTab.swift
//  PlayHub
//

import SwiftUI


struct SettingsTab: View {


    @EnvironmentObject var vm: PlayerVM


    @State private var showAddPlayer = false

    @State private var showHistoryAlert = false

    @State private var showDeleteAlert = false

    @State private var showLogoutAlert = false





    var body: some View {


        NavigationStack {


            Form {


                currentPlayerSection


                playersSection


                historySection


                aboutSection


            }



            .navigationTitle(
                "Settings"
            )



            .sheet(
                isPresented: $showAddPlayer
            ) {


                AddPlayerView(
                    vm: vm
                )


            }



            .onAppear {


                vm.refresh()


            }



            .onReceive(
                NotificationCenter.default.publisher(
                    for: .gameSaved
                )
            ) { _ in


                vm.refresh()


            }



            .onReceive(
                NotificationCenter.default.publisher(
                    for: .playerUpdated
                )
            ) { _ in


                vm.refresh()


            }







            .alert(
                "Logout?",
                isPresented:$showLogoutAlert
            ) {


                Button(
                    "Cancel",
                    role:.cancel
                ){}



                Button(
                    "Logout",
                    role:.destructive
                ){


                    vm.logout()


                }



            }








            .alert(
                "Clear History?",
                isPresented:$showHistoryAlert
            ) {



                Button(
                    "Cancel",
                    role:.cancel
                ){}



                Button(
                    "Clear",
                    role:.destructive
                ){


                    StorageService.shared
                        .clearHistory()


                    vm.refresh()


                }



            } message:{



                Text(
                    "All game history will be removed."
                )


            }








            .alert(
                "Delete All Data?",
                isPresented:$showDeleteAlert
            ){



                Button(
                    "Cancel",
                    role:.cancel
                ){}





                Button(
                    "Delete",
                    role:.destructive
                ){


                    StorageService.shared
                        .clearAllData()


                    vm.refresh()


                }




            } message:{



                Text(
                    "Players, scores and history will be deleted."
                )



            }



        }


    }







    // MARK: CURRENT PLAYER


    private var currentPlayerSection: some View {


        Section(
            "Current Player"
        ) {


            if let player = vm.player {



                PlayerCard(
                    player: player
                )



                VStack(
                    alignment:.leading,
                    spacing:8
                ) {



                    Label(
                        "Location",
                        systemImage:"location.fill"
                    )
                    .font(
                        .headline
                    )



                    if let location = player.locationName {



                        Text(
                            location
                        )
                        .font(
                            .caption
                        )
                        .foregroundStyle(
                            .secondary
                        )



                    } else {



                        Text(
                            "Location not saved yet"
                        )
                        .font(
                            .caption
                        )
                        .foregroundStyle(
                            .secondary
                        )


                    }



                }
                .padding(.vertical,8)





                Button {


                    showLogoutAlert = true



                } label:{



                    Label(
                        "Logout",
                        systemImage:
                            "rectangle.portrait.and.arrow.right"
                    )


                }



            } else {



                Text(
                    "No player selected"
                )
                .foregroundStyle(
                    .secondary
                )


            }


        }


    }    // MARK: PLAYERS
    
    
    private var playersSection: some View {


        Section(
            "Players"
        ) {



            Button {


                showAddPlayer = true


            } label:{



                Label(
                    "Add New Player",
                    systemImage:
                        "person.badge.plus"
                )


            }








            ForEach(
                vm.players,
                id:\.id
            ) { player in




                HStack {



                    Image(
                        systemName:
                            "person.circle.fill"
                    )
                    .font(
                        .title2
                    )





                    VStack(
                        alignment:.leading
                    ) {



                        Text(
                            player.name
                        )
                        .bold()





                        Text(
                            "Games: \(player.totalGames)"
                        )
                        .font(
                            .caption
                        )





                        Text(
                            "Best: \(player.bestScore)"
                        )
                        .font(
                            .caption
                        )






                        if let location = player.locationName {



                            Text(
                                "📍 Location Saved"
                            )
                            .font(
                                .caption
                            )
                            .foregroundStyle(
                                .green
                            )



                        } else {



                            Text(
                                "📍 Location not saved"
                            )
                            .font(
                                .caption
                            )
                            .foregroundStyle(
                                .secondary
                            )



                        }





                    }





                    Spacer()





                    if vm.player?.id == player.id {



                        Image(
                            systemName:
                                "checkmark.circle.fill"
                        )
                        .foregroundStyle(
                            .green
                        )



                    }




                }



                .contentShape(
                    Rectangle()
                )



                .onTapGesture {



                    vm.selectPlayer(
                        player
                    )


                }



            }



        }



    }









    // MARK: HISTORY


    private var historySection: some View {



        Section(
            "Data"
        ) {



            Button {



                showHistoryAlert = true


            } label:{



                Label(
                    "Clear Game History",
                    systemImage:
                        "trash"
                )


            }







            Button(
                role:.destructive
            ){



                showDeleteAlert = true


            } label:{



                Label(
                    "Delete All Data",
                    systemImage:
                        "trash.fill"
                )


            }



        }



    }    // MARK: ABOUT
    
    
    private var aboutSection: some View {


        Section(
            "About"
        ) {



            HStack {



                Text(
                    "App"
                )



                Spacer()



                Text(
                    "PlayHub"
                )
                .foregroundStyle(
                    .secondary
                )



            }







            HStack {



                Text(
                    "Version"
                )



                Spacer()



                Text(
                    "1.0"
                )
                .foregroundStyle(
                    .secondary
                )



            }



        }



    }


}
