//
// MainTabView.swift
// PlayHub
//

import SwiftUI


struct MainTabView: View {


    @State private var selectedTab = 0



    init() {


        let appearance =
        UITabBarAppearance()



        appearance.configureWithTransparentBackground()



        appearance.backgroundEffect =
        UIBlurEffect(
            style: .systemUltraThinMaterialDark
        )



        appearance.backgroundColor =
        UIColor.black.withAlphaComponent(0.35)






        appearance.stackedLayoutAppearance.normal.iconColor =
        UIColor.white.withAlphaComponent(0.45)



        appearance.stackedLayoutAppearance.normal.titleTextAttributes =
        [
            .foregroundColor:
                UIColor.white.withAlphaComponent(0.45)
        ]







        appearance.stackedLayoutAppearance.selected.iconColor =
        UIColor.systemGreen



        appearance.stackedLayoutAppearance.selected.titleTextAttributes =
        [
            .foregroundColor:
                UIColor.systemGreen
        ]





        UITabBar.appearance()
            .standardAppearance =
            appearance



        UITabBar.appearance()
            .scrollEdgeAppearance =
            appearance



    }








    var body: some View {



        ZStack {



            playHubBackground





            TabView(
                selection:
                    $selectedTab
            ) {





                HomeTab()

                    .tabItem {


                        Image(
                            systemName:
                                "house.fill"
                        )


                        Text(
                            "Home"
                        )

                    }

                    .tag(0)









                StatsTab()

                    .tabItem {


                        Image(
                            systemName:
                                "chart.bar.fill"
                        )


                        Text(
                            "Stats"
                        )


                    }

                    .tag(1)









                MapTab()

                    .tabItem {


                        Image(
                            systemName:
                                "map.fill"
                        )


                        Text(
                            "Map"
                        )


                    }

                    .tag(2)









                SettingsTab()

                    .tabItem {


                        Image(
                            systemName:
                                "gearshape.fill"
                        )


                        Text(
                            "Settings"
                        )


                    }

                    .tag(3)





            }


            .tint(
                Color.green
            )



        }



    }










    // MARK: Same theme as Light It Up


    var playHubBackground: some View {



        ZStack {



            LinearGradient(

                colors:[


                    Color.black,


                    Color(
                        red:0.02,
                        green:0.12,
                        blue:0.10
                    ),



                    Color(
                        red:0.03,
                        green:0.03,
                        blue:0.15
                    )


                ],


                startPoint:.topLeading,


                endPoint:.bottomTrailing


            )








            Circle()

                .fill(
                    Color.green.opacity(0.20)
                )

                .frame(
                    width:320,
                    height:320
                )

                .blur(
                    radius:90
                )

                .offset(
                    x:-150,
                    y:-300
                )










            Circle()

                .fill(
                    Color.cyan.opacity(0.18)
                )

                .frame(
                    width:280,
                    height:280
                )

                .blur(
                    radius:100
                )

                .offset(
                    x:150,
                    y:300
                )





        }

        .ignoresSafeArea()



    }



}




#Preview {


    MainTabView()


}
